package za.co.investec.address.print;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AddressPrint {
    public String prettyPrintAddress() {
        String prettyAddress = new String();
        for (Address a : read()) {
            prettyAddress += a + "\n";
        }
        return prettyAddress;
    }

    //reading the json file
    public List<Address> read() {
        List<Address> addresses = new ArrayList<>();
        int id;
        Type type;
        AddressLineDetail addressLineDetail;
        ProvinceOrState provinceOrState;
        String cityOrTown;
        Country country;
        int postalCode;


        JSONParser parser = new JSONParser();
        try {
            /*JSONArray arr = (JSONArray) parser.parse(new FileReader("C:\\Users\\Neo\\IdeaProjects\\Question2\\addresses.json"));
*/
            JSONArray arr = (JSONArray) parser.parse(new FileReader("src\\Address.json"));

            for (Object o : arr) {
                JSONObject addressesJson = (JSONObject) o;
                id = Integer.valueOf(addressesJson.get("id").toString());
                JSONObject JsonType = (JSONObject) addressesJson.get("type");

                JsonType.get("name");

                type = new Type(Integer.valueOf(JsonType.get("code").toString()), JsonType.get("name").toString());
                JSONObject JsonAddressLineDetail = (JSONObject) addressesJson.get("addressLineDetail");
                String line1 = null, line2 = null;

                if (JsonAddressLineDetail == null) {
                    line1 = " ";
                    line2 = " ";
                } else if (JsonAddressLineDetail != null) {
                    line1 = JsonAddressLineDetail.get("line1").toString();
                    line1 = JsonAddressLineDetail.get("line2").toString();
                    if (line1 == null)
                        line1 = " ";
                    if (line2 == null)
                        line2 = " ";
                }
                addressLineDetail = new AddressLineDetail(line1, line2);

                JSONObject JsonProvinceOrState = (JSONObject) addressesJson.get("provinceOrState");
                int code = 0;
                String name = null;
                if (JsonProvinceOrState == null) {
                    name = " ";
                } else if (JsonProvinceOrState != null) {
                    code = Integer.valueOf(JsonProvinceOrState.get("code").toString());
                    name = JsonProvinceOrState.get("name").toString();

                    if (name == null) {
                        name = " ";
                    }
                }
                provinceOrState = new ProvinceOrState(code, name);

                cityOrTown = addressesJson.get("cityOrTown").toString();

                JSONObject JsonCountry = (JSONObject) addressesJson.get("country");
                country = new Country(JsonCountry.get("code").toString(), JsonCountry.get("name").toString());

                postalCode = Integer.valueOf(addressesJson.get("postalCode").toString());

                addresses.add(new Address(id, type, addressLineDetail, provinceOrState, cityOrTown, country, postalCode));
            }


        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return addresses;
    }

    public void printSpecificAddress(String type) {
        for (Address a : read()) {
            if (a.getType().getName().toLowerCase().contains(type))
                System.out.println(a);
        }
    }


}
