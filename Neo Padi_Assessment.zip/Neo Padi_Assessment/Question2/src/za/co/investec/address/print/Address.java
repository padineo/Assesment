package za.co.investec.address.print;


public class Address {
    private int id;
    private Type type;
    private AddressLineDetail addressLineDetail;
    private ProvinceOrState provinceOrState;
    private String cityOrTown;
    private Country country;
    private int postalCode;

    @Override
    public String toString() {
        return type + ": " + addressLineDetail +
                "\n" + cityOrTown +
                "\n" + provinceOrState +
                "\n" + postalCode +
                "\n" + country;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public AddressLineDetail getAddressLineDetail() {
        return addressLineDetail;
    }

    public void setAddressLineDetail(AddressLineDetail addressLineDetail) {
        this.addressLineDetail = addressLineDetail;
    }

    public ProvinceOrState getProvinceOrState() {
        return provinceOrState;
    }

    public void setProvinceOrState(ProvinceOrState provinceOrState) {
        this.provinceOrState = provinceOrState;
    }

    public String getCityOrTown() {
        return cityOrTown;
    }

    public void setCityOrTown(String cityOrTown) {
        this.cityOrTown = cityOrTown;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    public int getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(int postalCode) {
        this.postalCode = postalCode;
    }

    public Address() {
    }

    public Address(int id, Type type, AddressLineDetail addressLineDetail, ProvinceOrState provinceOrState, String cityOrTown, Country country, int postalCode) {
        this.id = id;
        this.type = type;
        this.addressLineDetail = addressLineDetail;
        this.provinceOrState = provinceOrState;
        this.cityOrTown = cityOrTown;
        this.country = country;
        this.postalCode = postalCode;
    }
}
