package za.co.investec.address.print;

import java.util.List;

public class Question2 {
    public static void main(String[] args) {
        AddressPrint addressPrint = new AddressPrint();

        //output of pretty printing
        System.out.println(addressPrint.prettyPrintAddress());

        //output of printing a specific address
        System.out.println("Specific Address: ");
        addressPrint.printSpecificAddress("business");


        //output of addressValidation method
        List<Address> list = addressPrint.read();
        for (Address a : list) {
            System.out.println(AddressValidation.addressValidation(a));
        }

        System.out.println();

        //output of validationWithErrors method
        for (Address a : list) {
            for (String s : AddressValidation.validationWithErrors(a)) {
                System.out.println(s);
                System.out.println();
            }
        }
    }
}
