package za.co.investec.address.print;

public class Type {
    private int code;
    private String name;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Type(int code, String name) {
        this.code = code;
        this.name = name;
    }

    @Override
    public String toString() {
        return "\n" + name;
    }

}
