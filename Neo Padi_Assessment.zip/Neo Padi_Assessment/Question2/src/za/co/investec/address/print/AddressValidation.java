package za.co.investec.address.print;

import java.util.ArrayList;
import java.util.List;

public class AddressValidation {

    public static List<String> errors = new ArrayList<>();

    public static boolean addressValidation(Address address) {
        boolean outcome = false;
        try {
            address.setPostalCode(address.getPostalCode());
            if (address.getCountry().getName() != " " && address.getCountry().getName() != null)
                if ((address.getAddressLineDetail().getLine1() != "" || address.getAddressLineDetail().getLine2() != "") &&
                        (address.getAddressLineDetail().getLine1() != null || address.getAddressLineDetail().getLine2() != null))
                    if (address.getCountry().getCode().contains("ZA"))
                        if (address.getProvinceOrState() != null)
                            if (address.getProvinceOrState().getName() != " ")
                                outcome = true;
                            else if (!address.getCountry().getCode().contains("ZA"))
                                outcome = true;
                            else
                                outcome = false;
        } catch (Exception e) {
            outcome = false;
        }
        return outcome;
    }

    public boolean validateCountry(Country country, ProvinceOrState provinceOrState) {
        boolean outcome = false;
        if (country.getName() != " " && country.getName() != null) {
            if (country.getCode().contains("ZA")) {
                if (provinceOrState != null) {
                    if (provinceOrState.getName() != " ") {
                        outcome = true;
                    } else {
                        errors.add("province field is empty");
                    }
                } else {
                    errors.add("the province is not provided and as it should be cause the count is South Africa");
                }
            } else if (!country.getCode().contains("ZA")) {
                outcome = true;
            }
        } else {
            errors.add("No country has been specified");
            outcome = false;
        }
        return outcome;
    }

    public boolean validateAddressLine(AddressLineDetail addressLineDetail) {
        if ((addressLineDetail.getLine1() != "" || addressLineDetail.getLine2() != "") &&
                (addressLineDetail.getLine1() != null || addressLineDetail.getLine2() != null))
            return true;
        else {
            errors.add("No addressLine was given");
            return false;
        }
    }

    public static List<String> validationWithErrors(Address address) {
        AddressValidation a = new AddressValidation();
        errors.clear();
        if (a.validateCountry(address.getCountry(), address.getProvinceOrState()) &&
                a.validateAddressLine(address.getAddressLineDetail()))
            errors.add("Address is valid");

            return errors;
    }


}
