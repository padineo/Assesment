public class CommonDivisor {
    public static void main(String[] args) {

        int[] numbers = new int[]{12, 18};
        System.out.print("The Greatest Common Divisor for numbers : [ ");
        for (int i = 0; i < numbers.length; i++) {
            System.out.print(numbers[i] + " ");
        }
        System.out.print("] is " + highestCommonFactor(numbers));

    }

    private static int highestCommonFactor(int[] numbers) {
        boolean flag = true;
        int gcd = Integer.MAX_VALUE;
        int count = 0;
        while (flag) {
            for (int j : numbers) {
                if (j < gcd && j != 0) {
                    gcd = j;
                }
            }
            for (int i = 0; i < numbers.length; i++) {
                numbers[i] = numbers[i] % gcd;
                if (numbers[i] == 0) {
                    count++;
                    if (count == numbers.length) {
                        flag = false;
                        break;
                    }
                }
            }
        }
        return gcd;
    }
}
